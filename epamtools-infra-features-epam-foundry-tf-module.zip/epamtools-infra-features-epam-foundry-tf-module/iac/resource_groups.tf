module "rg_naming_convention" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7.7.0"

  for_each = local.resource_groups

  derived_from           = module.naming_convention
  append_contextual_name = each.value
}

resource "azurerm_resource_group" "resource_groups" {
  for_each = local.resource_groups

  name     = module.rg_naming_convention[each.key].resource_group
  location = var.location

  tags = module.tagging_convention.tags
}