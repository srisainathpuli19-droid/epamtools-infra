module "subnets_blocks" {
  source  = "hashicorp/subnets/cidr"
  version = "1.0.0"

  base_cidr_block = local.virtual_network_address_space

  networks = [
    for subnet in local.subnets_for_current_env :
    {
      name     = subnet.name
      new_bits = subnet.size - local.virtual_network_address_space_size
    }
  ]
}

module "subnets_naming_convention" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7.5.0"

  for_each = local.subnets_map

  derived_from           = module.naming_convention
  append_contextual_name = each.value.name
}

module "subnets" {
  for_each = local.subnets_map

  source = "git::https://github.com/opella-innersource/tf-mod-azure-subnet?ref=v3.5.0"

  name               = try(each.value.exact_name, false) ? each.value.name : module.subnets_naming_convention[each.key].subnet
  location           = var.location
  virtual_network_id = data.azurerm_virtual_network.epam_tools.id

  address_prefixes = [each.value.address_prefix]

  delegations = try(each.value.delegations, null)

  private_link_service_network_policies_enabled = try(each.value.private_link_service_network_policies_enabled, null)

  tags = module.tagging_convention.tags
}