# General variables

variable "subscription_id" {
  type        = string
  description = "The Azure subscription ID where the Azure Resources will be deployed."

  # Value is sourced from the ARM_SUBSCRIPTION_ID in CI environment
  default = null
}

variable "environment" {
  type        = string
  description = <<EOT
Represent a final environment (dev, int, prd, …).
Contrary to `environment_type`, this component cannot accept value that "group" environment together.
However, an environment of "mut" is accepted for resources shared across multiple environments.

To avoid confusion with environment type `prod`, `prd` should be used to design the specific `production` environment.
EOT

  validation {
    condition = contains(
      [
        "",
        "prod",
        "nonprod",
        "sand",
        "test",
        "dev",
        "stg",
        "trn",
        "uat",
      ],
    var.environment)

    error_message = "The `environment` must be one of: `prod`, `nonprod`, `sand`, `test`, `dev`, `stg`, `trn`, `uat`"
  }
}

variable "region_name" {
  type        = string
  description = <<EOT
Region where the resource is deployed.
Region are based on a specific naming convention and not on the Azure names.

Example: eu01, us01, ap01, glob (global), etc.
EOT

}

variable "location" {
  type        = string
  description = "Location where the resources will be deployed, e.g., swedencentral, westeurope"
}

variable "contextual_name" {
  type        = string
  description = "contextual name"
}

variable "application_id" {
  type        = string
  description = "application id, eg: APM0090733"
}

variable "app_category" {
  type        = string
  description = "app category, eg:bronze, gold, platinum"
}

variable "vm_sku" {
  type        = string
  default     = "Standard_D8s_v5"
  description = "VM SKU size"
}

variable "os_disk_type" {
  type        = string
  description = "virtual machine os disk type"
}

variable "os_disk_size" {
  type        = string
  description = "os disk size for vm"
}

variable "patch_wave_1" {
  type        = number
  description = "tag value 0 means patch_wave = 1"
}

variable "patch_wave_2" {
  type        = number
  description = "tag value 1 means patch_wave = 2"
}


