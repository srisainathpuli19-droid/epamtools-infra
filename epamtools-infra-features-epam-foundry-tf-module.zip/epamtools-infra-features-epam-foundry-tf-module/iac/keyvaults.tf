module "naming_convention_kv" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7.7.0"

  for_each = local.key_vaults

  environment            = var.environment
  region                 = var.region_name
  append_contextual_name = each.value.name
}

module "key_vault" {
  for_each = local.key_vaults

  source = "git::https://github.com/opella-innersource/tf-mod-azure-key-vault.git?ref=v1.6.0"

  name                      = module.naming_convention_kv[each.key].key_vault
  location                  = var.location
  resource_group_name       = azurerm_resource_group.resource_groups["migvisor"].name
  enable_rbac_authorization = true
  purge_protection_enabled  = var.environment == "prod" ? true : false
  tenant_id                 = data.azurerm_client_config.current.tenant_id

  tags = module.tagging_convention.tags
}