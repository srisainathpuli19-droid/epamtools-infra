module "linux_virtual_machine" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine.git?ref=v7.1.0"

  for_each = local.linux_vms

  name                = each.key
  location            = var.location
  resource_group_name = azurerm_resource_group.resource_groups["migvisor"].name
  sku                 = each.value.sku
  zone                = try(each.value.zone, null)
  subnet_id           = module.subnets["01"].id
  key_vault_id        = module.key_vault["passwords"].id
  os_disk_type        = each.value.os_disk_type
  os_disk_size_gb     = each.value.os_disk_size_gb
  data_disks          = each.value.data_disks
  # Image from locals.tf
  source_image_reference = local.linux_images[each.value.image_key]
  backup = {
    recovery_vault_name           = data.azurerm_recovery_services_vault.epam_vault.name
    recovery_vault_resource_group = data.azurerm_recovery_services_vault.epam_vault.resource_group_name
    backup_policy_id              = data.azurerm_backup_policy_vm.epam_policy.id
  }
  tags = module.tagging_convention.tags_for_vm[each.value.tag_index]
}